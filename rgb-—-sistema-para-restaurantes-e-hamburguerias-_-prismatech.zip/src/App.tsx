/**
 * RGB — Sistema de Gestão para Restaurantes e Hamburguerias
 * Prismatech Software e Suporte Ltda. (Medianeira - PR)
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { InteractiveShowcase } from './components/InteractiveShowcase';
import { RoiCalculator } from './components/RoiCalculator';
import { FeaturesBento } from './components/FeaturesBento';
import { ComparisonTable } from './components/ComparisonTable';
import { PricingSection } from './components/PricingSection';
import { Testimonials } from './components/Testimonials';
import { FaqSection } from './components/FaqSection';
import { TrialModal } from './components/TrialModal';
import { Footer } from './components/Footer';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [isTrialOpen, setIsTrialOpen] = useState(false);
  const [selectedPlanInfo, setSelectedPlanInfo] = useState<{ name: string; price: string } | null>(
    null
  );

  const handleOpenTrial = (planName?: string, price?: string) => {
    if (planName && price) {
      setSelectedPlanInfo({ name: planName, price });
    } else {
      setSelectedPlanInfo({ name: 'Plano Anual', price: 'R$ 89/mês' });
    }
    setIsTrialOpen(true);
  };

  const scrollToScreens = () => {
    const el = document.getElementById('demonstracao');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col antialiased">
      {/* Top Navigation */}
      <Navbar onOpenTrial={() => handleOpenTrial()} />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero onOpenTrial={() => handleOpenTrial()} onExploreScreens={scrollToScreens} />

        {/* Live Interactive Showcase of Real Product Screens (Prints 1-6) */}
        <InteractiveShowcase onOpenTrial={() => handleOpenTrial()} />

        {/* Economic / ROI Calculator */}
        <RoiCalculator onOpenTrial={() => handleOpenTrial()} />

        {/* Operational Pillars / Bento Grid */}
        <FeaturesBento onOpenTrial={() => handleOpenTrial()} />

        {/* Side-by-side Transparency Comparison */}
        <ComparisonTable />

        {/* Pricing Matrix */}
        <PricingSection
          onSelectPlan={(name, price) => handleOpenTrial(name, price)}
        />

        {/* Attributable Social Proof / Testimonials */}
        <Testimonials />

        {/* FAQ Accordion */}
        <FaqSection />

        {/* Final Conversion CTA Section */}
        <section className="py-16 md:py-24 bg-gradient-to-tr from-slate-900 via-slate-900 to-slate-950 text-white relative overflow-hidden">
          <div
            className="absolute top-0 right-0 w-96 h-96 bg-orange-600/10 blur-[100px] pointer-events-none"
            aria-hidden="true"
          />

          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-balance mb-6">
              Pronto para colocar o controle e o lucro do seu restaurante nas suas mãos?
            </h2>
            <p className="text-slate-400 text-base sm:text-lg max-w-2xl mx-auto mb-9 leading-relaxed">
              Crie sua loja em minutos e libere o acesso assim que confirmar seus dados. Teste por 7 dias sem nenhum risco.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
              <button
                onClick={() => handleOpenTrial()}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 text-base font-bold text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 rounded-xl shadow-lg shadow-orange-500/30 transition-all cursor-pointer active:scale-[0.98]"
              >
                <span>Começar 7 Dias Grátis Agora</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <a
                href="https://rgb.prismaweb.tech/"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-4 text-base font-semibold text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-xl border border-slate-700 transition-colors"
              >
                <span>Acessar Loja Demo</span>
              </a>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-slate-400 font-medium">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Sem taxa de adesão ou cancelamento</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Suporte humanizado no WhatsApp</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Roda em qualquer celular ou PC</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer />

      {/* Free Trial / Lead Modal */}
      <TrialModal
        isOpen={isTrialOpen}
        onClose={() => setIsTrialOpen(false)}
        initialPlan={selectedPlanInfo}
      />
    </div>
  );
}
