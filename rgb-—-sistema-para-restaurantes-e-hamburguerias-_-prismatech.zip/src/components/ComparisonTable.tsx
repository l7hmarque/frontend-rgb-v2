import React from 'react';
import { Check, X, Minus } from 'lucide-react';

export const ComparisonTable: React.FC = () => {
  const comparisons = [
    {
      feature: 'Taxa / Comissão sobre as vendas',
      rgb: '0% de comissão (Você fica com 100%)',
      marketplace: '12% a 27% retidos por pedido',
      desktop: 'Mensalidade + taxas extras',
    },
    {
      feature: 'Cardápio Digital Próprio com Link & QR Code',
      rgb: 'Incluso e personalizado com sua marca',
      marketplace: 'Não (o cliente fica no app deles)',
      desktop: 'Módulo cobrado à parte',
    },
    {
      feature: 'KDS Cozinha em Tempo Real',
      rgb: 'Incluso (Kanban, áudio e cronômetro)',
      marketplace: 'Não possui',
      desktop: 'Exige licença adicional cara',
    },
    {
      feature: 'Acesso pelo Celular / Tablet (PWA)',
      rgb: 'Sim, funciona em qualquer dispositivo',
      marketplace: 'Apenas portal de gestor',
      desktop: 'Não, preso no computador da loja',
    },
    {
      feature: 'Controle de Fiado & Contas a Receber',
      rgb: 'Incluso com limite e extrato WhatsApp',
      marketplace: 'Não possui',
      desktop: 'Básico ou inexistente',
    },
    {
      feature: 'Base de Clientes & Motor de Cupons',
      rgb: 'Os dados dos clientes são 100% seus',
      marketplace: 'Os clientes pertencem ao app',
      desktop: 'Sem motor de cupons online',
    },
    {
      feature: 'Custo de Implantação e Treinamento',
      rgb: 'R$ 0,00 (Comece em 5 minutos)',
      marketplace: 'Sem taxa de setup',
      desktop: 'R$ 800 a R$ 2.500 de taxa inicial',
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 mb-2">
            Transparência Absoluta
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance mb-4">
            Por que o RGB é a melhor escolha para o seu negócio?
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Compare o RGB com os aplicativos tradicionais de delivery e com sistemas antigos de computador.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[680px]">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="py-4 px-4 text-sm font-semibold text-slate-500 w-1/3">
                  Critérios Operacionais
                </th>
                <th className="py-4 px-4 text-base font-extrabold text-orange-600 bg-orange-50/70 rounded-t-2xl w-1/4 text-center border-t-2 border-orange-500">
                  RGB (Prismatech)
                </th>
                <th className="py-4 px-4 text-sm font-bold text-slate-700 w-1/4 text-center">
                  Marketplaces (iFood, etc.)
                </th>
                <th className="py-4 px-4 text-sm font-bold text-slate-700 w-1/4 text-center">
                  Sistemas Tradicionais Desktop
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              {comparisons.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                  <td className="py-4 px-4 font-bold text-slate-900">{row.feature}</td>
                  <td className="py-4 px-4 font-extrabold text-orange-700 bg-orange-50/40 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <Check className="w-4 h-4 text-orange-600 shrink-0" />
                      <span>{row.rgb}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-slate-600 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <X className="w-4 h-4 text-rose-500 shrink-0" />
                      <span>{row.marketplace}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4 text-slate-600 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <Minus className="w-4 h-4 text-slate-400 shrink-0" />
                      <span>{row.desktop}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
};
