import React from 'react';
import {
  Smartphone,
  CreditCard,
  ChefHat,
  NotebookTabs,
  PackageCheck,
  Tag,
  ArrowRight,
  CheckCircle,
} from 'lucide-react';

interface FeaturesBentoProps {
  onOpenTrial: () => void;
}

export const FeaturesBento: React.FC<FeaturesBentoProps> = ({ onOpenTrial }) => {
  return (
    <section id="recursos" className="py-16 md:py-24 bg-slate-50/60 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 mb-2">
            Arquitetura Operacional Completa
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance mb-4">
            Tudo o que sua hamburgueria e restaurante precisam em um só lugar
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Esqueça ter um sistema para o caixa, outro aplicativo para o cardápio e uma planilha perdida para o estoque. O RGB unifica toda a sua operação.
          </p>
        </div>

        {/* Bento Grid layout with asymmetric prominence */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Feature 1: Cardápio Digital (Col-span 7) */}
          <div className="md:col-span-7 bg-white p-7 sm:p-9 rounded-3xl border border-slate-200/90 shadow-xs flex flex-col justify-between hover:border-orange-200 transition-colors">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-orange-50 text-orange-600 flex items-center justify-center mb-6">
                <Smartphone className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                01. Self-Order & Delivery
              </span>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">
                Cardápio digital próprio sem taxas e sem intermediários
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Disponibilize seu link exclusivo no WhatsApp, Instagram e através de placas com QR Code nas mesas. Seu cliente monta o lanche, seleciona adicionais, escolhe pagar por PIX ou no recebimento e o pedido cai direto na cozinha.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center gap-y-2 gap-x-5 text-xs font-medium text-slate-600">
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                Sem taxa por pedido
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                QR Code para mesas
              </span>
              <span className="flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                Checkout PIX automático
              </span>
            </div>
          </div>

          {/* Feature 2: KDS Cozinha (Col-span 5) */}
          <div className="md:col-span-5 bg-white p-7 sm:p-9 rounded-3xl border border-slate-200/90 shadow-xs flex flex-col justify-between hover:border-orange-200 transition-colors">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-6">
                <ChefHat className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                02. KDS Cozinha
              </span>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">
                Cozinha ágil, sem gritaria e sem pedidos perdidos
              </h3>
              <p className="text-slate-600 text-sm leading-relaxed mb-6">
                Painel Kanban em tempo real para a chapa e montagem. Cronômetro de tempo de espera, aviso sonoro de novo pedido, observações em destaque e impressão térmica com 1 toque.
              </p>
            </div>
            <div className="pt-4 border-t border-slate-100 text-xs font-medium text-slate-600 flex items-center gap-2">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span>Redução comprovada de 90% em atrasos e erros</span>
            </div>
          </div>

          {/* Feature 3: Caixa e PDV (Col-span 4) */}
          <div className="md:col-span-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/90 shadow-xs flex flex-col justify-between hover:border-orange-200 transition-colors">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6">
                <CreditCard className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                03. Caixa & PDV
              </span>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Fechamento de caixa em 3 minutos
              </h3>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-4">
                Abertura, conferência cega, sangria, recebimentos parciais e divisão de conta por mesa. Sem furos no fim da noite.
              </p>
            </div>
            <div className="text-xs text-slate-500 pt-3 border-t border-slate-100">
              Relatório em PDF com 1 clique para a contabilidade.
            </div>
          </div>

          {/* Feature 4: Fiado e Contas a Receber (Col-span 4) */}
          <div className="md:col-span-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/90 shadow-xs flex flex-col justify-between hover:border-orange-200 transition-colors">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-6">
                <NotebookTabs className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                04. Fiado Organizado
              </span>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Adeus caderninho e calotes
              </h3>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-4">
                Cadastre clientes que compram fiado, estipule teto máximo de crédito, registre pagamentos parciais e envie extrato no WhatsApp.
              </p>
            </div>
            <div className="text-xs text-slate-500 pt-3 border-t border-slate-100">
              Segurança para você e transparência para o cliente.
            </div>
          </div>

          {/* Feature 5: Estoque & Ficha Técnica (Col-span 4) */}
          <div className="md:col-span-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/90 shadow-xs flex flex-col justify-between hover:border-orange-200 transition-colors">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-6">
                <PackageCheck className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                05. Estoque & Ficha
              </span>
              <h3 className="text-xl font-bold text-slate-900 mb-2">
                Baixa automática de insumos
              </h3>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-4">
                Vendeu 1 X-Burguer? O sistema desconta o pão, os 160g de carne e as fatias de cheddar. Alertas de insumos em falta antes de abrir a casa.
              </p>
            </div>
            <div className="text-xs text-slate-500 pt-3 border-t border-slate-100">
              Controle exato do CMV (Custo de Mercadoria Vendida).
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
