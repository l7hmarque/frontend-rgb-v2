import React, { useState } from 'react';
import { Menu, X, ArrowRight, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenTrial: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenTrial }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a href="#" className="flex items-center gap-3 shrink-0 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 via-orange-500 to-amber-500 flex items-center justify-center text-white font-black text-xl shadow-sm shadow-orange-500/20 group-hover:scale-105 transition-transform">
            RGB
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-extrabold tracking-tight text-slate-900 group-hover:text-orange-600 transition-colors">
              RGB
            </span>
            <span className="text-[11px] font-medium text-slate-500 -mt-1 tracking-wide">
              por Prismatech
            </span>
          </div>
        </a>

        {/* Zone 2: 5 single-line clean navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-600">
          <a
            href="#recursos"
            className="hover:text-orange-600 transition-colors whitespace-nowrap shrink-0"
          >
            Recursos
          </a>
          <a
            href="#demonstracao"
            className="hover:text-orange-600 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <span>Telas Reais</span>
            <span className="text-[10px] font-bold text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded border border-orange-200/60">
              Interativo
            </span>
          </a>
          <a
            href="#calculadora"
            className="hover:text-orange-600 transition-colors whitespace-nowrap shrink-0"
          >
            Calculadora de Economia
          </a>
          <a
            href="#planos"
            className="hover:text-orange-600 transition-colors whitespace-nowrap shrink-0"
          >
            Planos & Preços
          </a>
          <a
            href="#faq"
            className="hover:text-orange-600 transition-colors whitespace-nowrap shrink-0"
          >
            Dúvidas Frequentes
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <a
            href="https://rgb.prismaweb.tech/"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
          >
            Acessar Sistema
          </a>
          <button
            onClick={onOpenTrial}
            className="inline-flex items-center gap-2 px-4.5 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 rounded-xl shadow-sm shadow-orange-500/25 hover:shadow-md hover:shadow-orange-500/35 transition-all whitespace-nowrap shrink-0 active:scale-95 cursor-pointer"
          >
            <span>Começar 7 Dias Grátis</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Mobile menu button */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            onClick={onOpenTrial}
            className="px-3 py-1.5 text-xs font-bold text-white bg-orange-600 rounded-lg shadow-sm"
          >
            Testar
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-slate-600 hover:text-slate-900 rounded-lg focus:outline-none"
            aria-label="Abrir menu de navegação"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-200 bg-white px-4 pt-3 pb-5 space-y-3 shadow-lg">
          <nav className="flex flex-col gap-2 text-sm font-semibold text-slate-700">
            <a
              href="#recursos"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Recursos do Sistema
            </a>
            <a
              href="#demonstracao"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors flex items-center justify-between"
            >
              <span>Ver Telas Reais</span>
              <span className="text-xs text-orange-600 font-bold bg-orange-50 px-2 py-0.5 rounded">
                Interativo
              </span>
            </a>
            <a
              href="#calculadora"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Calculadora de Economia vs iFood
            </a>
            <a
              href="#planos"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Planos & Preços (A partir de R$ 89)
            </a>
            <a
              href="#faq"
              onClick={() => setMobileMenuOpen(false)}
              className="px-3 py-2 rounded-lg hover:bg-slate-100 transition-colors"
            >
              Perguntas Frequentes
            </a>
          </nav>
          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenTrial();
              }}
              className="w-full py-3 text-center text-sm font-bold text-white bg-orange-600 rounded-xl shadow-sm"
            >
              Começar Teste de 7 Dias Grátis
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
