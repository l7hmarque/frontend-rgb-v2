import React, { useState } from 'react';
import { X, CheckCircle, ArrowRight, ShieldCheck, Sparkles, MessageSquare } from 'lucide-react';

interface TrialModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialPlan?: { name: string; price: string } | null;
}

export const TrialModal: React.FC<TrialModalProps> = ({ isOpen, onClose, initialPlan }) => {
  const [restaurantName, setRestaurantName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('Medianeira - PR');
  const [selectedPlan, setSelectedPlan] = useState(initialPlan?.name || 'Plano Anual');
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!restaurantName.trim() || !ownerName.trim() || !phone.trim()) {
      setErrorMsg('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    // Basic Brazilian phone check
    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMsg('Por favor, insira um WhatsApp válido com DDD (mínimo 10 dígitos).');
      return;
    }

    setErrorMsg('');
    setSubmitted(true);
  };

  const handleWhatsAppRedirect = () => {
    const text = encodeURIComponent(
      `Olá, equipe Prismatech! Me chamo ${ownerName}, do restaurante/hamburgueria "${restaurantName}" em ${city}. Gostaria de ativar meu teste de 7 dias grátis do RGB no plano ${selectedPlan}.`
    );
    // WhatsApp direct link for Prismatech (Medianeira / PR)
    window.open(`https://wa.me/5545999000000?text=${text}`, '_blank');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="trial-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
    >
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative animate-in zoom-in-95">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          aria-label="Fechar janela"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-orange-600 uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Teste Grátis de 7 Dias</span>
            </div>
            <h3 id="trial-modal-title" className="text-2xl font-extrabold text-slate-900 mb-2">
              Comece a operar sem taxas hoje mesmo
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mb-6">
              Cadastre sua loja em menos de 2 minutos. Nossa equipe em Medianeira ajuda você a subir o cardápio e deixar tudo pronto para o seu próximo expediente.
            </p>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-medium border border-rose-200">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="font-semibold text-slate-800 block mb-1">
                  Nome da Hamburgueria / Restaurante <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: La Brasa Burgers ou Pizzaria Bella"
                  value={restaurantName}
                  onChange={(e) => setRestaurantName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500 text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-800 block mb-1">
                    Seu Nome <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Lucas Ferreira"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500 text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-800 block mb-1">
                    WhatsApp com DDD <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="(45) 99999-9999"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500 text-slate-900 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Cidade e Estado</label>
                  <input
                    type="text"
                    placeholder="Ex: Medianeira - PR"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:border-orange-500 text-slate-900"
                  />
                </div>

                <div>
                  <label className="font-semibold text-slate-800 block mb-1">Plano de Interesse</label>
                  <select
                    value={selectedPlan}
                    onChange={(e) => setSelectedPlan(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-orange-500"
                  >
                    <option value="Plano Anual">Plano Anual (R$ 89/mês)</option>
                    <option value="Plano Semestral">Plano Semestral (R$ 99/mês)</option>
                    <option value="Plano Mensal">Plano Mensal (R$ 119/mês)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 text-sm font-bold text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 rounded-xl shadow-md shadow-orange-500/25 transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
              >
                <span>Criar Minha Loja & Liberar Acesso</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Garantia de 7 dias sem taxa de cancelamento</span>
              </div>
            </form>
          </div>
        ) : (
          <div className="text-center py-4 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 mx-auto flex items-center justify-center">
              <CheckCircle className="w-10 h-10" />
            </div>

            <h3 className="text-2xl font-black text-slate-900">Pré-cadastro Concluído!</h3>

            <p className="text-sm text-slate-600 leading-relaxed max-w-sm mx-auto">
              Excelente, <strong>{ownerName}</strong>! Os dados da loja{' '}
              <strong>"{restaurantName}"</strong> foram registrados com sucesso no plano{' '}
              <strong>{selectedPlan}</strong>.
            </p>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-xs text-slate-600 text-left space-y-2">
              <div className="flex justify-between">
                <span className="font-semibold text-slate-700">Responsável:</span>
                <span>{ownerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold text-slate-700">WhatsApp:</span>
                <span className="font-mono">{phone}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-semibold text-slate-700">Local:</span>
                <span>{city}</span>
              </div>
            </div>

            <button
              onClick={handleWhatsAppRedirect}
              className="w-full py-3.5 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Falar Agora no WhatsApp da Prismatech</span>
            </button>

            <button
              onClick={onClose}
              className="text-xs text-slate-500 hover:text-slate-800 underline block mx-auto cursor-pointer"
            >
              Fechar e voltar para o site
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
