import React, { useState } from 'react';
import {
  CreditCard,
  ChefHat,
  Smartphone,
  Tag,
  Package,
  BarChart3,
  Check,
  Plus,
  Minus,
  ShoppingBag,
  Clock,
  Printer,
  Bike,
  DollarSign,
  ArrowRight,
  Sparkles,
  Volume2,
  FileText,
  AlertCircle,
  X,
  ExternalLink,
} from 'lucide-react';
import {
  INITIAL_PRODUCTS,
  INITIAL_KITCHEN_ORDERS,
  INITIAL_CASHIER_ORDERS,
  ProductItem,
  KitchenOrder,
  CashierOrder,
} from '../data/mockData';
import { FoodThumbnail } from './FoodThumbnail';
import { formatBRL, calculateOrderSummary } from '../utils/calculator';

interface InteractiveShowcaseProps {
  onOpenTrial: () => void;
}

export const InteractiveShowcase: React.FC<InteractiveShowcaseProps> = ({ onOpenTrial }) => {
  const [activeTab, setActiveTab] = useState<
    'caixa' | 'cozinha' | 'cardapio' | 'cupons' | 'produtos' | 'relatorios'
  >('caixa');

  // Interactive states for simulated screens
  // 1. Caixa state
  const [cashierOrders, setCashierOrders] = useState<CashierOrder[]>(INITIAL_CASHIER_ORDERS);
  const [cashBalance, setCashBalance] = useState<number>(0);
  const [sessionSales, setSessionSales] = useState<number>(0);
  const [cashierTab, setCashierTab] = useState<'a_receber' | 'mesas' | 'delivery' | 'concluidos'>('delivery');

  // 2. Cozinha state
  const [kitchenOrders, setKitchenOrders] = useState<KitchenOrder[]>(INITIAL_KITCHEN_ORDERS);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [lastActionToast, setLastActionToast] = useState<string | null>(null);

  // 3. Cardapio state
  const [cart, setCart] = useState<{ [key: string]: number }>({ 'prod-1': 1, 'prod-3': 1 });
  const [couponCode, setCouponCode] = useState('VOCENOCONTROLE');
  const [appliedCoupon, setAppliedCoupon] = useState<{ code: string; percent: number } | null>({
    code: 'VOCENOCONTROLE',
    percent: 10,
  });
  const [showCartDrawer, setShowCartDrawer] = useState(false);

  // 4. Cupons state
  const [couponForm, setCouponForm] = useState({
    code: 'VOCENOCONTROLE',
    desc: 'Crie seus proprios cupons de desconto!',
    type: 'Percentual (%)',
    percent: 10,
    minOrder: 30,
    maxDiscount: '',
    limitUses: 5,
    validFrom: '2026-10-18T20:42',
    validTo: '2026-10-24T20:42',
    isActive: true,
  });
  const [couponSavedToast, setCouponSavedToast] = useState(false);

  // 5. Produtos state
  const [productsList, setProductsList] = useState<ProductItem[]>(INITIAL_PRODUCTS);
  const [viewingRecipe, setViewingRecipe] = useState<ProductItem | null>(null);

  const showToast = (msg: string) => {
    setLastActionToast(msg);
    setTimeout(() => setLastActionToast(null), 3000);
  };

  // Helper actions
  const handleMarkDelivered = (orderId: string) => {
    setCashierOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: 'SAIU P/ ENTREGA' } : o))
    );
    showToast('Pedido marcado como: Saiu para entrega!');
  };

  const handleReceivePayment = (orderId: string, amount: number) => {
    setCashierOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, paymentStatus: 'PAGO PIX', status: 'ENTREGUE' } : o))
    );
    setCashBalance((prev) => prev + amount);
    setSessionSales((prev) => prev + amount);
    showToast(`Pagamento de ${formatBRL(amount)} recebido com sucesso no Caixa!`);
  };

  const advanceKitchenOrder = (orderId: string) => {
    setKitchenOrders((prev) =>
      prev.map((o) => {
        if (o.id === orderId) {
          if (o.status === 'a_preparar') return { ...o, status: 'em_preparo' };
          if (o.status === 'em_preparo') return { ...o, status: 'pronto' };
        }
        return o;
      })
    );
    showToast('Status do pedido atualizado na cozinha!');
  };

  const toggleProductStatus = (productId: string) => {
    setProductsList((prev) =>
      prev.map((p) =>
        p.id === productId ? { ...p, status: p.status === 'ATIVO' ? 'INATIVO' : 'ATIVO' } : p
      )
    );
  };

  // Cart calculations
  const cartItemsList = Object.entries(cart)
    .filter(([_, qty]) => qty > 0)
    .map(([id, qty]) => {
      const prod = INITIAL_PRODUCTS.find((p) => p.id === id);
      return {
        id,
        name: prod?.name || 'Item',
        price: prod?.price || 0,
        quantity: qty,
      };
    });

  const cartSummary = calculateOrderSummary(
    cartItemsList,
    9.0,
    appliedCoupon ? { code: appliedCoupon.code, type: 'percentage', value: appliedCoupon.percent, minOrder: 30 } : null
  );

  return (
    <section id="demonstracao" className="py-16 md:py-24 bg-white border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 mb-2">
            Experiência Real Sem Filtros
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance mb-4">
            Veja o RGB em funcionamento na sua operação
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Navegue pelas telas reais do sistema. Desenvolvido para ser leve, direto ao ponto e operável em qualquer tela sem complicação.
          </p>
        </div>

        {/* Tab Selector - Interactive Control */}
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto no-scrollbar gap-2 p-1.5 bg-slate-100 rounded-2xl mb-8 max-w-4xl mx-auto border border-slate-200/80">
          <button
            onClick={() => setActiveTab('caixa')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeTab === 'caixa'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>01. Caixa & PDV</span>
          </button>

          <button
            onClick={() => setActiveTab('cozinha')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeTab === 'cozinha'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <ChefHat className="w-4 h-4" />
            <span>02. KDS Cozinha</span>
          </button>

          <button
            onClick={() => setActiveTab('cardapio')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeTab === 'cardapio'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>03. Cardápio no Celular</span>
          </button>

          <button
            onClick={() => setActiveTab('cupons')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeTab === 'cupons'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Tag className="w-4 h-4" />
            <span>04. Cupons</span>
          </button>

          <button
            onClick={() => setActiveTab('produtos')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeTab === 'produtos'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>05. Produtos & Ficha</span>
          </button>

          <button
            onClick={() => setActiveTab('relatorios')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              activeTab === 'relatorios'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>06. Relatórios</span>
          </button>
        </div>

        {/* Global Toast Notification for Actions */}
        {lastActionToast && (
          <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{lastActionToast}</span>
          </div>
        )}

        {/* SCREEN CONTAINER - Modern clean card with hairline border */}
        <div className="bg-slate-50/80 rounded-3xl p-3 sm:p-6 lg:p-8 border border-slate-200/90 shadow-sm min-h-[580px] flex flex-col justify-between">
          {/* TAB 1: CAIXA / PDV (print2.jpg) */}
          {activeTab === 'caixa' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                    <span>Caixa</span>
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      ABERTO
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Visão geral de comandas, entregas e fluxo de caixa da sessão em tempo real.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button className="px-3 py-1.5 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200/60 transition-colors">
                    Fechar caixa
                  </button>
                  <button className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors">
                    Movimento
                  </button>
                </div>
              </div>

              {/* 3 Top Cards from print2.jpg */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200/80 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      COMANDAS ABERTAS
                    </span>
                    <span className="text-2xl font-extrabold text-slate-900 tabular-nums">3</span>
                  </div>
                  <div className="w-10 h-10 rounded-lg bg-rose-50 flex items-center justify-center text-rose-500">
                    <FileText className="w-5 h-5" />
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200/80 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      DELIVERIES ATIVOS
                    </span>
                    <span className="text-2xl font-extrabold text-slate-900 tabular-nums">
                      {cashierOrders.filter((o) => o.status !== 'ENTREGUE').length}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-lg bg-cyan-50 flex items-center justify-center text-cyan-600">
                    <Bike className="w-5 h-5" />
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200/80 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      AGUARDANDO PAGAMENTO
                    </span>
                    <span className="text-2xl font-extrabold text-slate-900 tabular-nums">
                      {cashierOrders.filter((o) => o.paymentStatus === 'PAGTO PENDENTE').length + 3}
                    </span>
                  </div>
                  <div className="w-10 h-10 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600">
                    <Clock className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Cash summary strip */}
              <div className="bg-white p-4 rounded-xl border border-slate-200/80 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-8">
                  <div>
                    <span className="text-xs text-slate-400 block">Saldo em caixa</span>
                    <span className="text-xl font-bold text-slate-900 tabular-nums">
                      {formatBRL(cashBalance)}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-slate-400 block">Vendas na sessão</span>
                    <span className="text-xl font-bold text-slate-900 tabular-nums">
                      {formatBRL(sessionSales)}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  <span>Operação conectada com KDS e WhatsApp</span>
                </div>
              </div>

              {/* Tabs: A receber, Mesas / Local, Delivery, Concluídos */}
              <div>
                <div className="flex items-center gap-6 border-b border-slate-200 text-sm font-semibold mb-4">
                  <button
                    onClick={() => setCashierTab('a_receber')}
                    className={`pb-2.5 transition-colors cursor-pointer ${
                      cashierTab === 'a_receber'
                        ? 'text-orange-600 border-b-2 border-orange-600'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    A receber
                  </button>
                  <button
                    onClick={() => setCashierTab('mesas')}
                    className={`pb-2.5 transition-colors cursor-pointer ${
                      cashierTab === 'mesas'
                        ? 'text-orange-600 border-b-2 border-orange-600'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Mesas / Local
                  </button>
                  <button
                    onClick={() => setCashierTab('delivery')}
                    className={`pb-2.5 transition-colors cursor-pointer ${
                      cashierTab === 'delivery'
                        ? 'text-orange-600 border-b-2 border-orange-600'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Delivery
                  </button>
                  <button
                    onClick={() => setCashierTab('concluidos')}
                    className={`pb-2.5 transition-colors cursor-pointer ${
                      cashierTab === 'concluidos'
                        ? 'text-orange-600 border-b-2 border-orange-600'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    Concluídos
                  </button>
                </div>

                {/* Orders Table from print2.jpg */}
                <div className="overflow-x-auto bg-white rounded-xl border border-slate-200/80">
                  <table className="w-full text-left text-xs sm:text-sm">
                    <thead className="bg-slate-50/80 text-slate-600 font-bold border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3">Pedido</th>
                        <th className="px-4 py-3">Local</th>
                        <th className="px-4 py-3">Cliente</th>
                        <th className="px-4 py-3">Total</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3">Pagamento</th>
                        <th className="px-4 py-3 text-right">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {cashierOrders.map((order) => (
                        <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-4 py-3.5">
                            <div className="font-bold text-slate-900">{order.code}</div>
                            <span className="inline-block text-[10px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded border border-purple-200">
                              {order.origin.toUpperCase()}
                            </span>
                            <div className="text-[11px] text-slate-400 mt-0.5">{order.timeStr}</div>
                          </td>
                          <td className="px-4 py-3.5 text-slate-700">{order.localType}</td>
                          <td className="px-4 py-3.5">
                            <div className="font-semibold text-slate-900">{order.customerName}</div>
                            <div className="text-[11px] text-slate-500">{order.phone}</div>
                          </td>
                          <td className="px-4 py-3.5 font-bold text-slate-900 tabular-nums">
                            {formatBRL(order.total)}
                          </td>
                          <td className="px-4 py-3.5">
                            <span
                              className={`inline-block px-2.5 py-1 rounded-md text-[11px] font-bold ${
                                order.status === 'PRONTO'
                                  ? 'bg-emerald-500 text-white'
                                  : order.status === 'SAIU P/ ENTREGA'
                                  ? 'bg-cyan-500 text-white'
                                  : order.status === 'ENTREGUE'
                                  ? 'bg-slate-800 text-white'
                                  : 'bg-amber-500 text-white'
                              }`}
                            >
                              {order.status}
                            </span>
                          </td>
                          <td className="px-4 py-3.5">
                            <span
                              className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                                order.paymentStatus.includes('PAGO')
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}
                            >
                              {order.paymentStatus}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-right space-x-1.5">
                            {order.status !== 'SAIU P/ ENTREGA' && order.status !== 'ENTREGUE' && (
                              <button
                                onClick={() => handleMarkDelivered(order.id)}
                                className="px-3 py-1.5 text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                              >
                                Sair p/ entrega
                              </button>
                            )}
                            {order.paymentStatus === 'PAGTO PENDENTE' && (
                              <button
                                onClick={() => handleReceivePayment(order.id, order.total)}
                                className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                              >
                                Receber pagamento
                              </button>
                            )}
                            <button className="text-xs text-slate-500 hover:text-slate-800 px-2 py-1">
                              Detalhes
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: KDS COZINHA (print3.jpg) */}
          {activeTab === 'cozinha' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                    <span>Cozinha (KDS)</span>
                    <span className="text-xs font-semibold text-slate-500">
                      Zero papelada, sincronizado em tempo real com garçons e delivery
                    </span>
                  </h3>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                    <Volume2 className="w-4 h-4 text-orange-600" />
                    <span>Som de aviso</span>
                    <button
                      onClick={() => setSoundEnabled(!soundEnabled)}
                      className={`w-9 h-5 rounded-full p-0.5 transition-colors cursor-pointer ${
                        soundEnabled ? 'bg-rose-500' : 'bg-slate-300'
                      }`}
                    >
                      <div
                        className={`w-4 h-4 bg-white rounded-full shadow-xs transform transition-transform ${
                          soundEnabled ? 'translate-x-4' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>
              </div>

              {/* 3 Columns Kanban from print3.jpg */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Column 1: A preparar */}
                <div className="bg-slate-100/70 p-3 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between mb-3 px-1">
                    <h4 className="font-bold text-slate-800 text-sm">A preparar</h4>
                    <span className="text-xs font-bold text-white bg-amber-500 px-2 py-0.5 rounded-full tabular-nums">
                      {kitchenOrders.filter((o) => o.status === 'a_preparar').length}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {kitchenOrders
                      .filter((o) => o.status === 'a_preparar')
                      .map((order) => (
                        <div
                          key={order.id}
                          className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-extrabold text-slate-900 text-sm">
                                {order.tableOrClient}
                              </div>
                              <span className="text-[11px] text-slate-400">{order.orderCode}</span>
                            </div>
                            <div className="text-right">
                              <span className="text-[11px] text-slate-400 block">{order.timeStr}</span>
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                                HÁ {order.minutesAgo} MIN
                              </span>
                            </div>
                          </div>

                          <div className="border-t border-slate-100 pt-2 text-xs text-slate-800 space-y-1 font-medium">
                            {order.items.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                                <span>{item}</span>
                              </div>
                            ))}
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => advanceKitchenOrder(order.id)}
                              className="flex-1 py-2 text-xs font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-lg transition-colors cursor-pointer"
                            >
                              Iniciar preparo
                            </button>
                            <button
                              onClick={() => showToast('Comanda enviada para impressora térmica!')}
                              className="px-3 py-2 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Imprimir</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Column 2: Em preparo */}
                <div className="bg-slate-100/70 p-3 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between mb-3 px-1">
                    <h4 className="font-bold text-slate-800 text-sm">Em preparo</h4>
                    <span className="text-xs font-bold text-white bg-orange-500 px-2 py-0.5 rounded-full tabular-nums">
                      {kitchenOrders.filter((o) => o.status === 'em_preparo').length}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {kitchenOrders
                      .filter((o) => o.status === 'em_preparo')
                      .map((order) => (
                        <div
                          key={order.id}
                          className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-extrabold text-slate-900 text-sm">
                                {order.tableOrClient}
                              </div>
                              <span className="text-[11px] text-slate-400">{order.orderCode}</span>
                            </div>
                            <div className="text-right">
                              <span className="text-[11px] text-slate-400 block">{order.timeStr}</span>
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                                HÁ {order.minutesAgo} MIN
                              </span>
                            </div>
                          </div>

                          <div className="border-t border-slate-100 pt-2 text-xs text-slate-800 space-y-1 font-medium">
                            {order.items.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                                <span>{item}</span>
                              </div>
                            ))}
                            {order.drinks && order.drinks.length > 0 && (
                              <div className="pt-1 text-[11px] text-slate-500">
                                <span className="font-semibold text-slate-700">Bebidas: </span>
                                {order.drinks.join(', ')}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => advanceKitchenOrder(order.id)}
                              className="flex-1 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors cursor-pointer"
                            >
                              Marcar pronto
                            </button>
                            <button
                              onClick={() => showToast('Comanda enviada para impressora térmica!')}
                              className="px-3 py-2 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Imprimir</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Column 3: Pronto */}
                <div className="bg-slate-100/70 p-3 rounded-2xl border border-slate-200">
                  <div className="flex items-center justify-between mb-3 px-1">
                    <h4 className="font-bold text-slate-800 text-sm">Pronto</h4>
                    <span className="text-xs font-bold text-white bg-emerald-600 px-2 py-0.5 rounded-full tabular-nums">
                      {kitchenOrders.filter((o) => o.status === 'pronto').length}
                    </span>
                  </div>

                  <div className="space-y-3">
                    {kitchenOrders
                      .filter((o) => o.status === 'pronto')
                      .map((order) => (
                        <div
                          key={order.id}
                          className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-extrabold text-slate-900 text-sm">
                                {order.tableOrClient}
                              </div>
                              <div className="flex items-center gap-1 mt-0.5">
                                <span className="text-[11px] text-slate-400">{order.orderCode}</span>
                                {order.isDigitalMenu && (
                                  <span className="text-[10px] font-bold text-purple-700 bg-purple-50 px-1 py-0.2 rounded border border-purple-200">
                                    CARDÁPIO DIGITAL
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-[11px] text-slate-400 block">{order.timeStr}</span>
                              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                                HÁ {order.minutesAgo} MIN
                              </span>
                            </div>
                          </div>

                          <div className="border-t border-slate-100 pt-2 text-xs text-slate-800 space-y-1 font-medium">
                            {order.items.map((item, idx) => (
                              <div key={idx} className="flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                <span>{item}</span>
                              </div>
                            ))}
                            {order.notes && (
                              <div className="text-[11px] font-bold text-amber-700 bg-amber-50 p-1.5 rounded border border-amber-200 mt-1">
                                Obs: {order.notes}
                              </div>
                            )}
                          </div>

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => showToast('Pedido despachado para entrega!')}
                              className="flex-1 py-2 text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-700 rounded-lg transition-colors cursor-pointer"
                            >
                              Saiu para Entrega
                            </button>
                            <button
                              onClick={() => showToast('Comanda enviada para impressora térmica!')}
                              className="px-3 py-2 text-xs font-semibold text-slate-600 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Imprimir</span>
                            </button>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CARDÁPIO DIGITAL NO CELULAR (print1.jpg) */}
          {activeTab === 'cardapio' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-in fade-in duration-200">
              <div className="lg:col-span-5 flex flex-col justify-center">
                <span className="text-xs font-bold text-orange-600 uppercase tracking-wider mb-2 block">
                  Cardápio Digital Próprio
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-4">
                  O cliente pede pelo link sem instalar nada e sem taxa de aplicativo
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed mb-6">
                  Seus clientes acessam o link direto do seu restaurante pelo WhatsApp ou escaneiam o QR Code na mesa. O pedido entra direto na sua cozinha e no caixa, com cálculo automático da taxa de entrega e pagamento instantâneo por PIX.
                </p>

                <div className="space-y-3 mb-6 text-sm text-slate-700">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>0% de comissão sobre cada lanche vendido</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Fotos apetitosas dos pratos em alta definição</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Motor de cupons exclusivo para reter clientes fiéis</span>
                  </div>
                </div>

                <div className="p-4 bg-orange-50 border border-orange-200 rounded-2xl">
                  <p className="text-xs text-orange-950 font-medium">
                    💡 <strong>Interaja com a simulação ao lado:</strong> Clique no botão vermelho (+) dos produtos para adicionar ao carrinho e veja o cálculo em tempo real!
                  </p>
                </div>
              </div>

              {/* Smartphone Frame with print1.jpg data */}
              <div className="lg:col-span-7 flex justify-center">
                <div className="w-full max-w-sm bg-white rounded-[40px] border-[10px] border-slate-900 shadow-2xl overflow-hidden flex flex-col h-[650px] relative">
                  {/* Smartphone Speaker Notch */}
                  <div className="bg-slate-900 w-32 h-5 mx-auto rounded-b-xl flex items-center justify-center">
                    <div className="w-12 h-1 bg-slate-700 rounded-full" />
                  </div>

                  {/* App Screen Content */}
                  <div className="p-4 overflow-y-auto flex-1 space-y-4 no-scrollbar">
                    {/* Header from print1.jpg */}
                    <div className="border-b border-slate-100 pb-3">
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white text-xs font-black shadow-xs">
                            ▲
                          </div>
                          <span className="font-extrabold text-slate-900 text-sm">
                            Prisma RGB Lanches 🍔
                          </span>
                        </div>
                        <span className="text-[10px] font-extrabold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                          ABERTO
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 mb-2">
                        O melhor do seu lanche, agora no digital.
                      </p>
                      <div className="text-[10px] text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-200/80 leading-relaxed">
                        PrismaTech - uma startup de Medianeira/PR com foco no comércio e economia local. Chega de sermos reféns das big techs e vamos construir juntos nosso próprio ecossistema local 🚀
                      </div>
                      <div className="mt-2 text-[10px] font-bold text-rose-600 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 inline-block">
                        TAXA DE ENTREGA: R$ 9,00
                      </div>
                    </div>

                    {/* Product Categories & Items from print1.jpg */}
                    <div className="space-y-4">
                      {/* Burgers */}
                      <div>
                        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                          Burgers
                        </div>
                        <div className="space-y-2">
                          {INITIAL_PRODUCTS.filter((p) => p.category === 'burger').map((prod) => (
                            <div
                              key={prod.id}
                              className="p-2.5 rounded-xl border border-slate-200/90 hover:border-slate-300 transition-colors flex items-center justify-between gap-3 bg-white"
                            >
                              <FoodThumbnail
                                src={prod.imageUrl}
                                alt={prod.name}
                                category={prod.category}
                                className="w-14 h-14 rounded-lg"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="font-bold text-xs text-slate-900 truncate">
                                  {prod.name}
                                </div>
                                <div className="text-xs font-extrabold text-slate-900 mt-0.5 tabular-nums">
                                  {formatBRL(prod.price)}
                                </div>
                              </div>
                              <button
                                onClick={() => {
                                  setCart((prev) => ({
                                    ...prev,
                                    [prod.id]: (prev[prod.id] || 0) + 1,
                                  }));
                                  showToast(`${prod.name} adicionado ao pedido!`);
                                }}
                                className="w-8 h-8 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center font-bold text-lg shadow-sm active:scale-95 transition-transform cursor-pointer"
                                aria-label={`Adicionar ${prod.name}`}
                              >
                                +
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Acompanhamentos */}
                      <div>
                        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                          Acompanhamentos
                        </div>
                        <div className="space-y-2">
                          {INITIAL_PRODUCTS.filter((p) => p.category === 'acompanhamento').map(
                            (prod) => (
                              <div
                                key={prod.id}
                                className="p-2.5 rounded-xl border border-slate-200/90 flex items-center justify-between gap-3 bg-white"
                              >
                                <FoodThumbnail
                                  src={prod.imageUrl}
                                  alt={prod.name}
                                  category={prod.category}
                                  className="w-14 h-14 rounded-lg"
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="font-bold text-xs text-slate-900 truncate">
                                    {prod.name}
                                  </div>
                                  <div className="text-xs font-extrabold text-slate-900 mt-0.5 tabular-nums">
                                    {formatBRL(prod.price)}
                                  </div>
                                </div>
                                <button
                                  onClick={() => {
                                    setCart((prev) => ({
                                      ...prev,
                                      [prod.id]: (prev[prod.id] || 0) + 1,
                                    }));
                                    showToast(`${prod.name} adicionado!`);
                                  }}
                                  className="w-8 h-8 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center font-bold text-lg shadow-sm active:scale-95 transition-transform cursor-pointer"
                                  aria-label={`Adicionar ${prod.name}`}
                                >
                                  +
                                </button>
                              </div>
                            )
                          )}
                        </div>
                      </div>

                      {/* Bebidas & Sobremesas */}
                      <div>
                        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                          Bebidas & Sobremesas
                        </div>
                        <div className="space-y-2">
                          {INITIAL_PRODUCTS.filter((p) =>
                            ['bebida', 'sobremesa'].includes(p.category)
                          ).map((prod) => (
                            <div
                              key={prod.id}
                              className="p-2.5 rounded-xl border border-slate-200/90 flex items-center justify-between gap-3 bg-white"
                            >
                              <FoodThumbnail
                                src={prod.imageUrl}
                                alt={prod.name}
                                category={prod.category}
                                className="w-14 h-14 rounded-lg"
                              />
                              <div className="flex-1 min-w-0">
                                <div className="font-bold text-xs text-slate-900 truncate">
                                  {prod.name}
                                </div>
                                <div className="text-xs font-extrabold text-slate-900 mt-0.5 tabular-nums">
                                  {formatBRL(prod.price)}
                                </div>
                              </div>
                              <button
                                onClick={() => {
                                  setCart((prev) => ({
                                    ...prev,
                                    [prod.id]: (prev[prod.id] || 0) + 1,
                                  }));
                                  showToast(`${prod.name} adicionado!`);
                                }}
                                className="w-8 h-8 rounded-full bg-rose-500 hover:bg-rose-600 text-white flex items-center justify-center font-bold text-lg shadow-sm active:scale-95 transition-transform cursor-pointer"
                                aria-label={`Adicionar ${prod.name}`}
                              >
                                +
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Bottom Cart Bar in Mobile Frame */}
                  {cartSummary.itemCount > 0 && (
                    <div className="p-3 bg-white border-t border-slate-200 shadow-lg flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-500 block">
                          Total ({cartSummary.itemCount} itens):
                        </span>
                        <span className="text-sm font-extrabold text-slate-900 tabular-nums">
                          {formatBRL(cartSummary.total)}
                        </span>
                        {cartSummary.discount > 0 && (
                          <span className="text-[10px] text-emerald-600 font-bold block">
                            (Cupom -{formatBRL(cartSummary.discount)})
                          </span>
                        )}
                      </div>
                      <button
                        onClick={() => setShowCartDrawer(!showCartDrawer)}
                        className="px-3.5 py-2 text-xs font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Ver Sacola</span>
                      </button>
                    </div>
                  )}

                  {/* Cart Drawer Simulation Modal */}
                  {showCartDrawer && (
                    <div className="absolute inset-0 bg-black/50 backdrop-blur-xs z-30 flex flex-col justify-end p-2 animate-in fade-in">
                      <div className="bg-white rounded-2xl p-4 space-y-3 max-h-[85%] overflow-y-auto">
                        <div className="flex items-center justify-between border-b pb-2">
                          <h5 className="font-bold text-sm text-slate-900">Seu Pedido</h5>
                          <button
                            onClick={() => setShowCartDrawer(false)}
                            className="p-1 text-slate-400 hover:text-slate-600"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        {cartItemsList.map((item) => (
                          <div
                            key={item.id}
                            className="flex items-center justify-between text-xs py-1"
                          >
                            <div className="font-medium text-slate-800">
                              {item.quantity}x {item.name}
                            </div>
                            <div className="font-bold text-slate-900 tabular-nums">
                              {formatBRL(item.price * item.quantity)}
                            </div>
                          </div>
                        ))}

                        <div className="border-t border-slate-100 pt-2 space-y-1 text-xs">
                          <div className="flex justify-between text-slate-500">
                            <span>Subtotal</span>
                            <span className="tabular-nums">{formatBRL(cartSummary.subtotal)}</span>
                          </div>
                          <div className="flex justify-between text-slate-500">
                            <span>Taxa de Entrega</span>
                            <span className="tabular-nums">{formatBRL(cartSummary.deliveryFee)}</span>
                          </div>
                          {cartSummary.discount > 0 && (
                            <div className="flex justify-between text-emerald-600 font-bold">
                              <span>Desconto Cupom ({appliedCoupon?.code})</span>
                              <span className="tabular-nums">-{formatBRL(cartSummary.discount)}</span>
                            </div>
                          )}
                          <div className="flex justify-between text-sm font-extrabold text-slate-900 border-t pt-1">
                            <span>Total Final</span>
                            <span className="tabular-nums">{formatBRL(cartSummary.total)}</span>
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setShowCartDrawer(false);
                            showToast('Pedido teste enviado direto para o WhatsApp e KDS!');
                          }}
                          className="w-full py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors cursor-pointer"
                        >
                          Enviar Pedido via WhatsApp / PIX
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CUPONS & FIDELIDADE (print4.jpg) */}
          {activeTab === 'cupons' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center animate-in fade-in duration-200">
              <div className="lg:col-span-5">
                <span className="text-xs font-bold text-orange-600 uppercase tracking-wider mb-2 block">
                  Motor de Retenção
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-4">
                  Crie campanhas irresistíveis e traga seu cliente de volta
                </h3>
                <p className="text-slate-600 text-sm leading-relaxed mb-6">
                  Nos marketplaces tradicionais, o cliente é da plataforma e você não pode sequer mandar mensagem para ele. No RGB, você é o dono da sua base: crie cupons com limite de usos, valor mínimo e data de expiração para movimentar dias fracos como terças e quartas.
                </p>

                <div className="space-y-3 mb-6 text-sm text-slate-700">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Desconto percentual ou valor fixo em reais</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Controle de pedido mínimo para garantir lucro</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Limite de utilizações e validade programada</span>
                  </div>
                </div>
              </div>

              {/* Exact Cupom Modal Mockup from print4.jpg */}
              <div className="lg:col-span-7 flex justify-center">
                <div className="w-full max-w-md bg-white rounded-2xl border border-slate-300 shadow-xl p-5 space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <h4 className="font-bold text-base text-slate-900">Novo cupom</h4>
                    <span className="text-slate-400 text-lg cursor-pointer">×</span>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Código <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={couponForm.code}
                      onChange={(e) => setCouponForm({ ...couponForm, code: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm font-mono font-bold uppercase rounded-lg border border-slate-300 focus:outline-none focus:border-rose-500 text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">
                      Descrição (opcional)
                    </label>
                    <input
                      type="text"
                      value={couponForm.desc}
                      onChange={(e) => setCouponForm({ ...couponForm, desc: e.target.value })}
                      className="w-full px-3 py-2 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:border-rose-500 text-slate-700"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">Tipo</label>
                      <select
                        value={couponForm.type}
                        onChange={(e) => setCouponForm({ ...couponForm, type: e.target.value })}
                        className="w-full px-3 py-2 text-xs sm:text-sm rounded-lg border border-slate-300 bg-white"
                      >
                        <option>Percentual (%)</option>
                        <option>Valor Fixo (R$)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">
                        Desconto (%) <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="number"
                        value={couponForm.percent}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, percent: Number(e.target.value) })
                        }
                        className="w-full px-3 py-2 text-xs sm:text-sm rounded-lg border border-slate-300"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">
                        Pedido mínimo (R$)
                      </label>
                      <input
                        type="number"
                        value={couponForm.minOrder}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, minOrder: Number(e.target.value) })
                        }
                        className="w-full px-3 py-2 text-xs sm:text-sm rounded-lg border border-slate-300"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-0.5">
                        Teto do desconto (R$)
                      </label>
                      <span className="text-[10px] text-slate-400 block mb-1">Só para percentual</span>
                      <input
                        type="number"
                        placeholder="Opcional"
                        className="w-full px-3 py-2 text-xs sm:text-sm rounded-lg border border-slate-300"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 block mb-0.5">
                      Limite de usos
                    </label>
                    <span className="text-[10px] text-slate-400 block mb-1">
                      Deixe vazio para ilimitado
                    </span>
                    <input
                      type="number"
                      value={couponForm.limitUses}
                      onChange={(e) =>
                        setCouponForm({ ...couponForm, limitUses: Number(e.target.value) })
                      }
                      className="w-full px-3 py-2 text-xs sm:text-sm rounded-lg border border-slate-300"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">
                        Válido a partir de
                      </label>
                      <input
                        type="datetime-local"
                        value={couponForm.validFrom}
                        onChange={(e) =>
                          setCouponForm({ ...couponForm, validFrom: e.target.value })
                        }
                        className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-300"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-700 block mb-1">
                        Válido até
                      </label>
                      <input
                        type="datetime-local"
                        value={couponForm.validTo}
                        onChange={(e) => setCouponForm({ ...couponForm, validTo: e.target.value })}
                        className="w-full px-2 py-1.5 text-xs rounded-lg border border-slate-300"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-3 pt-1">
                    <button
                      onClick={() =>
                        setCouponForm({ ...couponForm, isActive: !couponForm.isActive })
                      }
                      className={`w-10 h-6 rounded-full p-0.5 transition-colors cursor-pointer ${
                        couponForm.isActive ? 'bg-rose-500' : 'bg-slate-300'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 bg-white rounded-full shadow-xs transform transition-transform ${
                          couponForm.isActive ? 'translate-x-4' : 'translate-x-0'
                        }`}
                      />
                    </button>
                    <span className="text-xs font-semibold text-slate-800">
                      {couponForm.isActive ? 'Ativo' : 'Inativo'}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      setAppliedCoupon({
                        code: couponForm.code,
                        percent: couponForm.percent,
                      });
                      showToast(`Cupom ${couponForm.code} salvo e ativado no sistema!`);
                    }}
                    className="w-full py-3 text-xs sm:text-sm font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Salvar
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: PRODUTOS & FICHA TÉCNICA (print5.jpg) */}
          {activeTab === 'produtos' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Produtos</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Catálogo completo, ficha técnica, preços e controle de visibilidade em 1 clique.
                  </p>
                </div>
                <button
                  onClick={() => showToast('Abrir modal de novo produto!')}
                  className="px-4 py-2 text-xs font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Novo produto
                </button>
              </div>

              {/* Products Table from print5.jpg */}
              <div className="overflow-x-auto bg-white rounded-xl border border-slate-200/80">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-3">Nome</th>
                      <th className="px-4 py-3">Categoria</th>
                      <th className="px-4 py-3">Preço</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {productsList.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <FoodThumbnail
                              src={item.imageUrl}
                              alt={item.name}
                              category={item.category}
                              className="w-10 h-10 rounded-lg border border-slate-200"
                            />
                            <div>
                              <div className="font-bold text-slate-900">{item.name}</div>
                              <div className="text-[11px] text-slate-400 line-clamp-1 max-w-xs">
                                {item.description}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-slate-600 capitalize">{item.category}</td>
                        <td className="px-4 py-3 font-bold text-slate-900 tabular-nums">
                          {formatBRL(item.price)}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold ${
                              item.status === 'ATIVO'
                                ? 'bg-emerald-500 text-white'
                                : 'bg-slate-400 text-white'
                            }`}
                          >
                            {item.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right space-x-1">
                          <button className="px-2 py-1 text-xs text-rose-600 bg-rose-50 hover:bg-rose-100 rounded border border-rose-200 transition-colors">
                            Editar
                          </button>
                          <button
                            onClick={() => setViewingRecipe(item)}
                            className="px-2 py-1 text-xs text-purple-700 bg-purple-50 hover:bg-purple-100 rounded border border-purple-200 transition-colors"
                          >
                            Receita
                          </button>
                          <button
                            onClick={() => toggleProductStatus(item.id)}
                            className="px-2 py-1 text-xs text-slate-600 bg-slate-50 hover:bg-slate-100 rounded border border-slate-200 transition-colors"
                          >
                            {item.status === 'ATIVO' ? 'Desativar' : 'Ativar'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Recipe Modal */}
              {viewingRecipe && (
                <div className="fixed inset-0 bg-black/40 backdrop-blur-xs z-50 flex items-center justify-center p-4">
                  <div className="bg-white rounded-2xl p-6 max-w-md w-full space-y-4 shadow-xl border border-slate-200">
                    <div className="flex items-center justify-between border-b pb-3">
                      <div>
                        <h4 className="font-bold text-slate-900 text-base">
                          Ficha Técnica & Receita
                        </h4>
                        <span className="text-xs text-slate-500">{viewingRecipe.name}</span>
                      </div>
                      <button
                        onClick={() => setViewingRecipe(null)}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="text-xs text-slate-600 space-y-2">
                      <p>
                        A baixa de estoque acontece automaticamente a cada venda registrada no caixa ou cardápio:
                      </p>
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5 font-mono">
                        <div className="flex justify-between">
                          <span>1x Pão Artesanal</span>
                          <span className="text-slate-500">Estoque: 84 un</span>
                        </div>
                        <div className="flex justify-between">
                          <span>160g Blend Bovino</span>
                          <span className="text-slate-500">Estoque: 14.2 kg</span>
                        </div>
                        <div className="flex justify-between">
                          <span>2x Fatias Queijo Cheddar</span>
                          <span className="text-slate-500">Estoque: 110 un</span>
                        </div>
                        <div className="flex justify-between">
                          <span>20g Molho da Casa</span>
                          <span className="text-slate-500">Estoque: 3.5 L</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setViewingRecipe(null)}
                      className="w-full py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl"
                    >
                      Fechar
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: RELATÓRIOS & INSIGHTS (print6.jpg) */}
          {activeTab === 'relatorios' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
                <div>
                  <h3 className="text-2xl font-bold text-slate-900">Relatórios</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    DRE diário, formas de pagamento, top produtos e métricas de produção.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="px-3 py-1.5 text-xs font-mono font-semibold bg-white border border-slate-200 rounded-lg text-slate-700">
                    08/10/2026 📅
                  </div>
                  <button
                    onClick={() => showToast('Snapshot gerado e salvo com sucesso!')}
                    className="px-3 py-1.5 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 transition-colors"
                  >
                    Gerar snapshot
                  </button>
                  <button
                    onClick={() => showToast('Download do PDF completo iniciado!')}
                    className="px-3 py-1.5 text-xs font-bold text-white bg-rose-500 hover:bg-rose-600 rounded-lg shadow-xs transition-colors"
                  >
                    Baixar PDF
                  </button>
                </div>
              </div>

              {/* Informative notification from print6.jpg */}
              <div className="bg-sky-50 text-sky-900 text-xs px-4 py-2.5 rounded-xl border border-sky-200/80">
                Snapshot salvo em 2026-10-08 — total R$ 86,00 · 4 pedido(s).
              </div>

              {/* 3 Metrics Cards from print6.jpg */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200/80">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    TOTAL DE VENDAS
                  </span>
                  <span className="text-2xl font-extrabold text-slate-900 tabular-nums">
                    R$ 86,00
                  </span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200/80">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    PEDIDOS CONCLUÍDOS
                  </span>
                  <span className="text-2xl font-extrabold text-slate-900 tabular-nums">4</span>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200/80 space-y-1 text-xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    FORMAS DE PAGAMENTO
                  </span>
                  <div className="flex justify-between text-slate-600">
                    <span>Dinheiro:</span>
                    <span className="font-bold tabular-nums">R$ 9,00</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Cartão crédito:</span>
                    <span className="font-bold tabular-nums">R$ 77,00</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>PIX:</span>
                    <span className="font-bold tabular-nums">R$ 0,00</span>
                  </div>
                </div>
              </div>

              {/* Top produtos do dia from print6.jpg */}
              <div className="bg-white rounded-xl border border-slate-200/80 overflow-hidden">
                <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 font-bold text-xs sm:text-sm text-slate-900">
                  Top produtos do dia
                </div>
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-slate-50/50 text-slate-500 border-b border-slate-100">
                    <tr>
                      <th className="px-4 py-2.5">Produto</th>
                      <th className="px-4 py-2.5">Qtd</th>
                      <th className="px-4 py-2.5 text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                    <tr>
                      <td className="px-4 py-2.5">Coca-Cola Lata 350ml</td>
                      <td className="px-4 py-2.5 tabular-nums">4</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">R$ 24,00</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2.5">X-Burguer</td>
                      <td className="px-4 py-2.5 tabular-nums">3</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">R$ 27,00</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2.5">Brownie</td>
                      <td className="px-4 py-2.5 tabular-nums">3</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">R$ 21,00</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2.5">Batata-Frita G 500g</td>
                      <td className="px-4 py-2.5 tabular-nums">3</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">R$ 42,00</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2.5">X-Salada</td>
                      <td className="px-4 py-2.5 tabular-nums">1</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">R$ 10,00</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2.5">Combo Casal</td>
                      <td className="px-4 py-2.5 tabular-nums">1</td>
                      <td className="px-4 py-2.5 text-right tabular-nums">R$ 28,00</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Extras do dia from print6.jpg */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div className="bg-white p-4 rounded-xl border border-slate-200/80">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    FINANCEIRO
                  </span>
                  <div className="flex justify-between text-slate-700">
                    <span>Taxa de entrega</span>
                    <span className="font-bold tabular-nums">R$ 9,00</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200/80 space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    PRODUÇÃO
                  </span>
                  <div className="flex justify-between text-slate-700">
                    <span>Lanches delivery</span>
                    <span className="font-bold tabular-nums">2</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Lanches locais</span>
                    <span className="font-bold tabular-nums">9</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Bebidas</span>
                    <span className="font-bold tabular-nums">4</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200/80 space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    TEMPOS MÉDIOS
                  </span>
                  <div className="flex justify-between text-slate-700">
                    <span>Preparo médio</span>
                    <span className="font-bold tabular-nums">14 min</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Entrega média</span>
                    <span className="font-bold tabular-nums">22 min</span>
                  </div>
                  <div className="flex justify-between text-slate-700">
                    <span>Cancelamentos</span>
                    <span className="font-bold tabular-nums text-emerald-600">0</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Bottom Bar: Action & Trust */}
          <div className="mt-8 pt-4 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
              <Sparkles className="w-4 h-4 text-orange-600 shrink-0" />
              <span>
                Todas as telas acima funcionam perfeitamente integradas na sua hamburgueria ou restaurante.
              </span>
            </div>
            <button
              onClick={onOpenTrial}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-all cursor-pointer whitespace-nowrap"
            >
              <span>Quero Usar Essa Operação na Minha Loja</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
