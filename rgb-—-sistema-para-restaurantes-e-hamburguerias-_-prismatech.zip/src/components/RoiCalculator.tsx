import React, { useState } from 'react';
import { Calculator, TrendingDown, ArrowRight, DollarSign, ShieldAlert } from 'lucide-react';
import { calculateMarketplaceSavings, formatBRL } from '../utils/calculator';

interface RoiCalculatorProps {
  onOpenTrial: () => void;
}

export const RoiCalculator: React.FC<RoiCalculatorProps> = ({ onOpenTrial }) => {
  const [revenue, setRevenue] = useState<number>(20000);
  const [feeRate, setFeeRate] = useState<number>(20);

  const savings = calculateMarketplaceSavings(revenue, feeRate, 89);

  return (
    <section id="calculadora" className="py-16 md:py-24 bg-slate-900 text-white relative overflow-hidden">
      {/* Background ambient lighting */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-5xl h-96 bg-orange-600/10 blur-[120px] pointer-events-none"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-bold text-orange-400 uppercase tracking-wider bg-orange-950/60 border border-orange-800/60 px-3 py-1 rounded-full mb-3">
            <Calculator className="w-3.5 h-3.5" />
            <span>Simulador de Lucro Real</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-balance mb-4">
            Quanto dinheiro o seu restaurante está perdendo para as big techs?
          </h2>
          <p className="text-slate-400 text-base sm:text-lg">
            Descubra quanto você economiza no mês e no ano migrando seus clientes fiéis para o seu Cardápio Digital próprio com taxa 0%.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-slate-800/90 backdrop-blur-md rounded-3xl p-6 sm:p-10 border border-slate-700/80 shadow-2xl">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Sliders on Left */}
            <div className="md:col-span-7 space-y-7">
              {/* Slider 1: Revenue */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-semibold text-slate-300">
                    Seu faturamento mensal no delivery
                  </label>
                  <span className="text-lg font-extrabold text-orange-400 font-mono tabular-nums">
                    {formatBRL(revenue)}
                  </span>
                </div>
                <input
                  type="range"
                  min={5000}
                  max={80000}
                  step={1000}
                  value={revenue}
                  onChange={(e) => setRevenue(Number(e.target.value))}
                  className="w-full h-2.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-orange-500"
                />
                <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-mono">
                  <span>R$ 5.000</span>
                  <span>R$ 40.000</span>
                  <span>R$ 80.000+</span>
                </div>
              </div>

              {/* Slider 2: Fee Rate */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-semibold text-slate-300">
                    Taxa média atual que você paga (iFood / outros)
                  </label>
                  <span className="text-lg font-extrabold text-rose-400 font-mono tabular-nums">
                    {feeRate}%
                  </span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={27}
                  step={1}
                  value={feeRate}
                  onChange={(e) => setFeeRate(Number(e.target.value))}
                  className="w-full h-2.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-rose-500"
                />
                <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-mono">
                  <span>10% (Básico)</span>
                  <span>20% (Padrão)</span>
                  <span>27% (Com entrega)</span>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/70 border border-slate-700 text-xs text-slate-300 flex items-start gap-3">
                <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <p>
                  Hoje você entrega{' '}
                  <strong className="text-rose-400 font-mono">{formatBRL(savings.marketplaceCost)}</strong>{' '}
                  todo mês de mão beijada para o aplicativo. Com o RGB você investe apenas{' '}
                  <strong className="text-emerald-400 font-mono">R$ 89,00/mês</strong> fixo, sem comissões.
                </p>
              </div>
            </div>

            {/* Result Box on Right */}
            <div className="md:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 p-6 sm:p-7 rounded-2xl border border-orange-500/30 flex flex-col justify-between text-center relative">
              <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                Sua Economia Líquida
              </div>

              <div className="my-4">
                <span className="text-xs text-slate-400 block mb-0.5">Por mês você poupa:</span>
                <div className="text-3xl sm:text-4xl font-black text-emerald-400 font-mono tabular-nums">
                  {formatBRL(savings.monthlySavings)}
                </div>
              </div>

              <div className="py-3 border-y border-slate-800 my-2">
                <span className="text-xs text-slate-400 block mb-0.5">Em 1 ano você guarda:</span>
                <div className="text-2xl sm:text-3xl font-extrabold text-orange-400 font-mono tabular-nums">
                  {formatBRL(savings.annualSavings)}
                </div>
              </div>

              <p className="text-[11px] text-slate-400 mt-2 mb-4">
                Dinheiro suficiente para reformar a cozinha, comprar novos equipamentos ou colocar no caixa.
              </p>

              <button
                onClick={onOpenTrial}
                className="w-full py-3.5 text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 rounded-xl shadow-lg shadow-orange-500/30 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Quero Reter Esse Lucro</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
