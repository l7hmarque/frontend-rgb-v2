import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs py-14 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Brand info */}
          <div className="md:col-span-5 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-orange-600 flex items-center justify-center text-white font-extrabold text-sm">
                RGB
              </div>
              <span className="text-lg font-bold text-white tracking-tight">RGB</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Sistema de gestão completo para restaurantes e hamburguerias: pedidos, cardápio digital, comanda eletrônica, caixa, estoque e relatórios sem comissão por venda.
            </p>
            <div className="text-[11px] text-slate-500">
              Um produto desenvolvido por{' '}
              <a
                href="https://prismaweb.tech"
                target="_blank"
                rel="noopener noreferrer"
                className="text-orange-400 hover:text-orange-300 font-medium underline"
              >
                Prismatech
              </a>
            </div>
          </div>

          {/* Nav links column 1 */}
          <div className="md:col-span-4 space-y-2">
            <div className="text-slate-200 font-bold uppercase tracking-wider text-[11px] mb-3">
              Módulos do Sistema
            </div>
            <ul className="space-y-2">
              <li>
                <a href="#demonstracao" className="hover:text-white transition-colors">
                  Cardápio Digital no Celular
                </a>
              </li>
              <li>
                <a href="#demonstracao" className="hover:text-white transition-colors">
                  KDS Cozinha em Tempo Real
                </a>
              </li>
              <li>
                <a href="#demonstracao" className="hover:text-white transition-colors">
                  Caixa & PDV Completo
                </a>
              </li>
              <li>
                <a href="#demonstracao" className="hover:text-white transition-colors">
                  Fiado e Contas a Receber
                </a>
              </li>
              <li>
                <a href="#demonstracao" className="hover:text-white transition-colors">
                  Controle de Estoque & Ficha Técnica
                </a>
              </li>
            </ul>
          </div>

          {/* Legal column */}
          <div className="md:col-span-3 space-y-2">
            <div className="text-slate-200 font-bold uppercase tracking-wider text-[11px] mb-3">
              Transparência & Contato
            </div>
            <ul className="space-y-2">
              <li>
                <a href="#planos" className="hover:text-white transition-colors">
                  Planos a partir de R$ 89/mês
                </a>
              </li>
              <li>
                <a href="#calculadora" className="hover:text-white transition-colors">
                  Simulador de Economia
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Perguntas Frequentes
                </a>
              </li>
              <li className="pt-2 text-slate-500 text-[11px]">
                Atendimento: leonardo.marque@prismatecnologias.com.br
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <div>
            PRISMATECH SOFTWARE E SUPORTE LTDA. · CNPJ 76.635.861/0001-08 · Medianeira - PR
          </div>
          <div>© {new Date().getFullYear()} RGB — Todos os direitos reservados.</div>
        </div>
      </div>
    </footer>
  );
};
