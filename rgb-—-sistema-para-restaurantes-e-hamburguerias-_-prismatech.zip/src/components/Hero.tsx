import React from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, Zap, Smartphone, TrendingUp, Sparkles } from 'lucide-react';

interface HeroProps {
  onOpenTrial: () => void;
  onExploreScreens: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenTrial, onExploreScreens }) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24 bg-gradient-to-b from-white via-slate-50/50 to-slate-100/60 border-b border-slate-200/80">
      {/* Subtle background glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-orange-100/40 via-amber-100/30 to-transparent blur-3xl pointer-events-none -z-10"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          {/* Quiet clean metadata line - No pill badge */}
          <div className="flex items-center justify-center gap-2 text-xs sm:text-sm font-semibold text-slate-600 mb-5">
            <span className="text-orange-600">Medianeira/PR & Brasil</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span>Hamburguerias & Restaurantes</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <span className="text-emerald-700 font-bold">Zero Taxa por Pedido</span>
          </div>

          {/* Main Headline with balanced wrap */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.12] mb-6 text-balance">
            Do cardápio ao caixa e cozinha.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 via-orange-500 to-amber-600">
              O sistema que devolve o seu lucro.
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg lg:text-xl text-slate-600 leading-relaxed max-w-2xl mx-auto mb-9">
            Chega de ser refém das taxas abusivas de 12% a 27% dos aplicativos. Tenha seu próprio cardápio digital, comanda eletrônica, KDS na cozinha e PDV rápido — 100% no navegador e celular.
          </p>

          {/* Dual CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
            <button
              onClick={onOpenTrial}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 text-base font-bold text-white bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 rounded-xl shadow-md shadow-orange-500/25 hover:shadow-lg hover:shadow-orange-500/35 transition-all cursor-pointer active:scale-[0.98]"
            >
              <span>Testar 7 Dias Grátis</span>
              <ArrowRight className="w-5 h-5" />
            </button>
            <button
              onClick={onExploreScreens}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-4 text-base font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300/80 rounded-xl shadow-xs hover:border-slate-400 transition-all cursor-pointer"
            >
              <span>Ver Telas Reais em Ação</span>
            </button>
          </div>

          {/* Micro trust signals */}
          <div className="flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs sm:text-sm text-slate-500 font-medium">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Sem taxa de adesão</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Roda no celular (PWA) e PC</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Garantia de 7 dias (CDC)</span>
            </div>
          </div>
        </div>

        {/* 4-Item Proof & KPI Grid below hero */}
        <div className="mt-14 pt-8 border-t border-slate-200/70 grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-2 text-orange-600 mb-1">
              <TrendingUp className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Sua Margem
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              0% Comissões
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Todo o dinheiro do seu cliente vai direto para o seu bolso.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-2 text-emerald-600 mb-1">
              <Zap className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Velocidade
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              3 minutos
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Para abrir, movimentar e fechar o caixa sem furos nem caderninho.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-2 text-blue-600 mb-1">
              <Smartphone className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Mobilidade
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              100% PWA
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Sem programas pesados. Funciona no Android, iPhone e notebook.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-2 text-amber-600 mb-1">
              <ShieldCheck className="w-4 h-4" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Acessível
              </span>
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
              R$ 89<span className="text-base font-normal text-slate-500">/mês</span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Plano anual completo com todos os recursos inclusos.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
