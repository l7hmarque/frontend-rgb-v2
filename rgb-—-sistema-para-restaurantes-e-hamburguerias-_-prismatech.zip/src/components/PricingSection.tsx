import React, { useState } from 'react';
import { Check, ShieldCheck, ArrowRight, Zap } from 'lucide-react';

interface PricingSectionProps {
  onSelectPlan: (planName: string, price: string) => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onSelectPlan }) => {
  const [billingCycle, setBillingCycle] = useState<'anual' | 'semestral' | 'mensal'>('anual');

  const plans = [
    {
      id: 'mensal',
      name: 'Plano Mensal',
      badge: 'Sem Fidelidade',
      price: '119',
      period: '/mês',
      commitment: 'Cancele quando quiser, sem fidelidade',
      description: 'Ideal para quem quer testar mês a mês com total liberdade.',
      popular: false,
    },
    {
      id: 'anual',
      name: 'Plano Anual',
      badge: 'Mais Escolhido',
      price: '89',
      period: '/mês',
      commitment: 'Economize R$ 360 no ano · Cobrado anualmente',
      description: 'A solução definitiva com o menor custo fixo para o seu restaurante.',
      popular: true,
    },
    {
      id: 'semestral',
      name: 'Plano Semestral',
      badge: 'Intermediário',
      price: '99',
      period: '/mês',
      commitment: 'Compromisso de 6 meses',
      description: 'Equilíbrio ideal entre economia e flexibilidade.',
      popular: false,
    },
  ];

  const includedFeatures = [
    'Cardápio Digital Próprio com link e QR Code ilimitados',
    'Zero taxa ou comissão sobre pedidos',
    'Painel KDS Cozinha com som e cronômetro',
    'Caixa & PDV com controle de sangria e fechamento',
    'Gestão de Mesas, Comandas e Garçons',
    'Controle de Fiado com limite e histórico por cliente',
    'Gestão de Estoque com Ficha Técnica e baixa automática',
    'Motor de Cupons de Desconto e Promoções',
    'Relatórios completos de vendas e exportação em PDF',
    'Suporte direto via WhatsApp com a equipe da Prismatech',
  ];

  return (
    <section id="planos" className="py-16 md:py-24 bg-slate-50/70 border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="text-xs font-bold uppercase tracking-wider text-orange-600 mb-2">
            Planos Claros & Preço Justo
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance mb-4">
            Investimento que se paga nos primeiros dias
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Sem taxas escondidas, sem cobrança por usuário ou mesa. Todos os recursos liberados desde o primeiro dia.
          </p>
        </div>

        {/* Plan Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto items-stretch">
          {plans.map((plan) => {
            const isHighlighted = plan.popular;
            return (
              <div
                key={plan.id}
                className={`bg-white rounded-3xl p-7 flex flex-col justify-between transition-all ${
                  isHighlighted
                    ? 'border-2 border-orange-500 shadow-xl shadow-orange-500/10 relative md:-translate-y-2'
                    : 'border border-slate-200/90 shadow-sm hover:border-slate-300'
                }`}
              >
                {isHighlighted && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-orange-600 to-amber-500 text-white text-[11px] font-extrabold px-3.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                    Melhor Custo-Benefício
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-bold text-slate-900">{plan.name}</h3>
                    <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                      {plan.badge}
                    </span>
                  </div>

                  <p className="text-xs text-slate-500 min-h-[32px] mb-6">{plan.description}</p>

                  <div className="flex items-baseline gap-1 mb-2">
                    <span className="text-sm font-bold text-slate-400">R$</span>
                    <span className="text-4xl sm:text-5xl font-black text-slate-900 tabular-nums">
                      {plan.price}
                    </span>
                    <span className="text-sm font-semibold text-slate-500">{plan.period}</span>
                  </div>

                  <div className="text-xs font-medium text-orange-700 bg-orange-50 px-2.5 py-1.5 rounded-lg border border-orange-200/60 mb-6">
                    {plan.commitment}
                  </div>

                  <div className="space-y-2.5 text-xs text-slate-700 mb-8 border-t border-slate-100 pt-5">
                    {includedFeatures.map((feat, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-100">
                  <button
                    onClick={() => onSelectPlan(plan.name, `R$ ${plan.price}/mês`)}
                    className={`w-full py-3.5 text-xs sm:text-sm font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 ${
                      isHighlighted
                        ? 'bg-orange-600 hover:bg-orange-700 text-white shadow-md shadow-orange-500/25'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                  >
                    <span>Começar com {plan.name}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <div className="text-[11px] text-center text-slate-400">
                    7 dias de garantia incondicional pelo CDC
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Guarantee Banner */}
        <div className="mt-14 max-w-3xl mx-auto bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs flex flex-col sm:flex-row items-center gap-5">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div className="text-center sm:text-left">
            <h4 className="font-bold text-slate-900 text-sm sm:text-base">
              Garantia Legal de 7 Dias — Risco Zero
            </h4>
            <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
              Você assina, testa em toda a sua hamburgueria ou restaurante durante 7 dias corridos. Se por qualquer motivo achar que não é para você, basta nos avisar e devolvemos 100% do seu dinheiro, sem perguntas e sem complicação (Art. 49 do Código de Defesa do Consumidor).
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
