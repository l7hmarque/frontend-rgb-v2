import React, { useState } from 'react';
import { Utensils, Coffee, Beer, Sparkles } from 'lucide-react';

interface FoodThumbnailProps {
  src: string;
  alt: string;
  category: string;
  className?: string;
}

export const FoodThumbnail: React.FC<FoodThumbnailProps> = ({
  src,
  alt,
  category,
  className = 'w-12 h-12 rounded-lg',
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    let bgGradient = 'from-amber-500 to-orange-600 text-white';
    let label = '🍔';

    if (category === 'acompanhamento') {
      bgGradient = 'from-yellow-500 to-amber-600 text-white';
      label = '🍟';
    } else if (category === 'bebida') {
      bgGradient = 'from-emerald-500 to-teal-600 text-white';
      label = '🥤';
    } else if (category === 'sobremesa') {
      bgGradient = 'from-rose-500 to-pink-600 text-white';
      label = '🍫';
    } else if (category === 'combo') {
      bgGradient = 'from-purple-600 to-indigo-700 text-white';
      label = '🍔🍟';
    }

    return (
      <div
        className={`${className} bg-gradient-to-tr ${bgGradient} flex items-center justify-center font-bold text-base shadow-xs shrink-0 select-none`}
        title={alt}
      >
        <span>{label}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={`${className} object-cover shrink-0`}
    />
  );
};
