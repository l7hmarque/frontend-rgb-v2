/**
 * Faithful domain data based on RGB / Prismatech (Medianeira - PR)
 * and screenshots print1.jpg to print6.jpg
 */

export interface ProductItem {
  id: string;
  name: string;
  description: string;
  category: 'burger' | 'acompanhamento' | 'bebida' | 'sobremesa' | 'combo';
  price: number;
  imageUrl: string;
  status: 'ATIVO' | 'INATIVO';
  recipeCount: number;
}

export const INITIAL_PRODUCTS: ProductItem[] = [
  {
    id: 'prod-1',
    name: 'X-Burguer',
    description: 'Pão brioche artesanal, burger 160g bovino grelhado, queijo cheddar duplo e maionese da casa.',
    category: 'burger',
    price: 9.0,
    imageUrl: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 4,
  },
  {
    id: 'prod-2',
    name: 'X-Salada',
    description: 'Pão brioche, burger 160g, queijo prato, alface americana fresca, tomate maduro e molho especial.',
    category: 'burger',
    price: 10.0,
    imageUrl: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 6,
  },
  {
    id: 'prod-3',
    name: 'Batata-Frita G 500g',
    description: 'HAMBURGUER BEM GOSTOSO - Batatas selecionadas crocantes por fora e macias por dentro com sal marinho.',
    category: 'acompanhamento',
    price: 14.0,
    imageUrl: 'https://images.unsplash.com/photo-1576107232684-1279f3908594?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 2,
  },
  {
    id: 'prod-4',
    name: 'Cerveja Heineken Long Neck',
    description: 'Cerveja puro malte gelada 330ml.',
    category: 'bebida',
    price: 10.0,
    imageUrl: 'https://images.unsplash.com/photo-1608270114023-e187dc67098f?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 1,
  },
  {
    id: 'prod-5',
    name: 'Coca-Cola Lata 350ml',
    description: 'Refrigerante Coca-Cola original gelado 350ml.',
    category: 'bebida',
    price: 6.0,
    imageUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 1,
  },
  {
    id: 'prod-6',
    name: 'Combo Casal',
    description: '2x X-Burguer + 1x Batata G 500g + 2x Refrigerantes em lata. O combo perfeito para dividir.',
    category: 'combo',
    price: 28.0,
    imageUrl: 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 8,
  },
  {
    id: 'prod-7',
    name: 'Brownie',
    description: 'Brownie artesanal de chocolate belga 70% com nozes picadas.',
    category: 'sobremesa',
    price: 7.0,
    imageUrl: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&auto=format&fit=crop&q=80',
    status: 'ATIVO',
    recipeCount: 5,
  },
];

export interface KitchenOrder {
  id: string;
  orderCode: string;
  tableOrClient: string;
  origin: 'LOCAL' | 'DELIVERY';
  isDigitalMenu?: boolean;
  timeStr: string;
  minutesAgo: number;
  items: string[];
  drinks?: string[];
  notes?: string;
  status: 'a_preparar' | 'em_preparo' | 'pronto';
}

export const INITIAL_KITCHEN_ORDERS: KitchenOrder[] = [
  {
    id: 'k-1',
    orderCode: 'L-0001',
    tableOrClient: 'Mesa 3',
    origin: 'LOCAL',
    timeStr: '18:46',
    minutesAgo: 6,
    items: ['1x Brownie'],
    status: 'a_preparar',
  },
  {
    id: 'k-2',
    orderCode: 'L-0003',
    tableOrClient: 'Mesa 2',
    origin: 'LOCAL',
    timeStr: '17:05',
    minutesAgo: 12,
    items: ['1x X-Salada'],
    status: 'a_preparar',
  },
  {
    id: 'k-3',
    orderCode: 'L-0002',
    tableOrClient: 'Mesa 1',
    origin: 'LOCAL',
    timeStr: '17:04',
    minutesAgo: 15,
    items: ['1x X-Burguer', '1x Batata-Frita G 500g', '1x Brownie'],
    drinks: ['1x Coca-Cola Lata 350ml'],
    status: 'em_preparo',
  },
  {
    id: 'k-4',
    orderCode: 'D-0004',
    tableOrClient: 'Nome Teste (45) 99142-0721',
    origin: 'DELIVERY',
    isDigitalMenu: true,
    timeStr: '21:48',
    minutesAgo: 1,
    items: ['1x X-Burguer', '1x Batata-Frita G 500g'],
    drinks: ['1x Coca-Cola Lata 350ml'],
    notes: 'sem cebola e sem salada',
    status: 'pronto',
  },
];

export interface CashierOrder {
  id: string;
  code: string;
  origin: 'Cardápio Digital' | 'Mesa' | 'Balcão';
  localType: 'Delivery' | 'Mesa / Local' | 'Retirada';
  customerName: string;
  phone: string;
  total: number;
  timeStr: string;
  status: 'PRONTO' | 'EM PREPARO' | 'SAIU P/ ENTREGA' | 'ENTREGUE';
  paymentStatus: 'PAGTO PENDENTE' | 'PAGO PIX' | 'PAGO CARTÃO' | 'PAGO DINHEIRO';
}

export const INITIAL_CASHIER_ORDERS: CashierOrder[] = [
  {
    id: 'c-1',
    code: 'D-0004',
    origin: 'Cardápio Digital',
    localType: 'Delivery',
    customerName: 'Nome Teste',
    phone: '45991420721',
    total: 38.0,
    timeStr: '21:48',
    status: 'PRONTO',
    paymentStatus: 'PAGTO PENDENTE',
  },
  {
    id: 'c-2',
    code: 'D-0005',
    origin: 'Cardápio Digital',
    localType: 'Delivery',
    customerName: 'Mariana Silva',
    phone: '45998114422',
    total: 52.0,
    timeStr: '21:52',
    status: 'EM PREPARO',
    paymentStatus: 'PAGO PIX',
  },
  {
    id: 'c-3',
    code: 'L-0002',
    origin: 'Mesa',
    localType: 'Mesa / Local',
    customerName: 'Mesa 1 - Carlos',
    phone: 'Presencial',
    total: 36.0,
    timeStr: '17:04',
    status: 'PRONTO',
    paymentStatus: 'PAGO CARTÃO',
  },
];

export const FAQS = [
  {
    q: 'Preciso instalar algum programa ou comprar computador caro?',
    a: 'Não! O RGB roda 100% no navegador e como aplicativo leve no celular (PWA). Você pode usar o celular que já tem, tablets, notebooks ou computadores antigos. Sua equipe acessa com login e senha próprios, cada um com sua permissão (cozinha, garçom, caixa ou dono).',
  },
  {
    q: 'Como funciona a fidelidade e o cancelamento?',
    a: 'Você é livre. No plano mensal não existe qualquer fidelidade. Nos planos com desconto (semestral ou anual), caso precise cancelar antes, a cobrança é apenas proporcional ao desconto usufruído — nunca cobramos o valor integral restante.',
  },
  {
    q: 'Tem garantia de arrependimento?',
    a: 'Sim: nos 7 dias seguintes à contratação você pode testar todo o sistema e, se não amar, cancelar com devolução integral e sem nenhuma multa (conforme o art. 49 do Código de Defesa do Consumidor).',
  },
  {
    q: 'Como é feita a cobrança da mensalidade?',
    a: 'A mensalidade é cobrada de forma automática e segura no cartão de crédito (recorrente sem prender o limite total) via Mercado Pago, ou via PIX. A renovação acontece de forma transparente a cada ciclo.',
  },
  {
    q: 'Como funciona o cardápio digital próprio sem comissão?',
    a: 'Você recebe um link exclusivo (ex: rgb.prismaweb.tech/seurestaurante) com fotos dos seus pratos, adicionais, cálculo de entrega e pagamento via PIX ou na entrega. Seus clientes pedem sem precisar baixar nada e você não paga nenhum centavo de comissão por pedido!',
  },
  {
    q: 'Quem desenvolve o RGB e onde fica a empresa?',
    a: 'O RGB é desenvolvido pela PRISMATECH SOFTWARE E SUPORTE LTDA. (CNPJ 76.635.861/0001-08), com sede em Medianeira, Paraná. Nosso foco é apoiar os comércios locais com tecnologia de ponta, suporte humanizado de verdade e preço justo.',
  },
];

export const TESTIMONIALS = [
  {
    name: 'Lucas Ferreira',
    role: 'Proprietário',
    business: 'La Brasa Hamburgueria Artesanal',
    city: 'Medianeira - PR',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    quote:
      'Estávamos pagando quase R$ 3.800 por mês só em comissões de marketplaces. Com o cardápio digital da RGB colocamos o link na bio do Instagram e no WhatsApp. Em 30 dias mais de 60% dos clientes fiéis migraram. Além disso, a cozinha com o KDS nunca mais errou um ponto de carne.',
    metrics: '+R$ 4.100/mês de economia líquida',
  },
  {
    name: 'Patrícia Zanella',
    role: 'Sócia-fundadora',
    business: 'Ponto do Lanche & Porções',
    city: 'Foz do Iguaçu - PR',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    quote:
      'Nosso maior problema era o fiado no caderninho e o fechamento do caixa que demorava 1 hora toda madrugada. O RGB organizou tudo: comanda das mesas, delivery e o fiado com limite por cliente. Fecho o caixa em 3 minutos e vejo o relatório no celular deitada na cama.',
    metrics: 'Fechamento de caixa em 3 min',
  },
  {
    name: 'Rodrigo M. Camargo',
    role: 'Chef e Gerente',
    business: 'Burger & Beer 45',
    city: 'Cascavel - PR',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    quote:
      'O suporte da Prismatech é sensacional, respondem na hora pelo WhatsApp. O sistema não trava, é super leve no celular do garçom e o cliente elogia a rapidez de pedir pelo QR Code na mesa sem esperar garçom trazer o cardápio físico.',
    metrics: '0 erros de comanda em 6 meses',
  },
];
