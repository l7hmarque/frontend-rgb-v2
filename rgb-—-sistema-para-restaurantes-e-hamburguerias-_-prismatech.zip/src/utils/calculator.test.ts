import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateMarketplaceSavings, applyCoupon, calculateOrderSummary } from './calculator.ts';

test('calculateMarketplaceSavings computes correct monthly and annual savings', () => {
  // R$ 20.000 revenue at 20% commission -> R$ 4.000 commission - R$ 89 RGB cost = R$ 3.911 savings
  const result = calculateMarketplaceSavings(20000, 20, 89);
  assert.equal(result.marketplaceCost, 4000);
  assert.equal(result.rgbCost, 89);
  assert.equal(result.monthlySavings, 3911);
  assert.equal(result.annualSavings, 46932);
});

test('calculateMarketplaceSavings handles 0 revenue and boundary cases', () => {
  const result = calculateMarketplaceSavings(0, 15, 89);
  assert.equal(result.marketplaceCost, 0);
  assert.equal(result.monthlySavings, 0);
  assert.equal(result.annualSavings, 0);
});

test('applyCoupon calculates percentage coupon correctly with minOrder and maxDiscount', () => {
  const coupon = {
    code: 'VOCENOCONTROLE',
    type: 'percentage' as const,
    value: 10,
    minOrder: 30,
    maxDiscount: 15,
  };

  // Under min order -> 0 discount
  assert.equal(applyCoupon(25, coupon), 0);

  // Normal order -> 10% of 40 = 4
  assert.equal(applyCoupon(40, coupon), 4);

  // Large order capped by maxDiscount
  assert.equal(applyCoupon(200, coupon), 15);
});

test('calculateOrderSummary calculates correct order total', () => {
  const items = [
    { id: '1', name: 'X-Burguer', price: 9.0, quantity: 2 },
    { id: '2', name: 'Batata-Frita G 500g', price: 14.0, quantity: 1 },
  ];
  // Subtotal = 18 + 14 = 32
  // Delivery = 9
  // Total = 41
  const summary = calculateOrderSummary(items, 9);
  assert.equal(summary.subtotal, 32);
  assert.equal(summary.itemCount, 3);
  assert.equal(summary.deliveryFee, 9);
  assert.equal(summary.discount, 0);
  assert.equal(summary.total, 41);
});
