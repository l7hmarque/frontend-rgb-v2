/**
 * Business logic calculations for restaurant ROI, order totals and discounts
 */

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Coupon {
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minOrder?: number;
  maxDiscount?: number;
}

export function formatBRL(amount: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(amount);
}

export function calculateMarketplaceSavings(
  monthlyDeliveryRevenue: number,
  marketplacePercent: number,
  rgbCostPerMonth: number = 89
): {
  marketplaceCost: number;
  rgbCost: number;
  monthlySavings: number;
  annualSavings: number;
  savingsPercentage: number;
} {
  const safeRevenue = Math.max(0, monthlyDeliveryRevenue);
  const safePercent = Math.max(0, Math.min(100, marketplacePercent));
  const marketplaceCost = safeRevenue * (safePercent / 100);
  const rgbCost = rgbCostPerMonth;
  const monthlySavings = Math.max(0, marketplaceCost - rgbCost);
  const annualSavings = monthlySavings * 12;
  const savingsPercentage = safeRevenue > 0 ? (monthlySavings / (safeRevenue + 0.0001)) * 100 : 0;

  return {
    marketplaceCost: Math.round(marketplaceCost * 100) / 100,
    rgbCost,
    monthlySavings: Math.round(monthlySavings * 100) / 100,
    annualSavings: Math.round(annualSavings * 100) / 100,
    savingsPercentage: Math.round(savingsPercentage * 10) / 10,
  };
}

export function applyCoupon(subtotal: number, coupon?: Coupon | null): number {
  if (!coupon || subtotal <= 0) return 0;
  if (coupon.minOrder && subtotal < coupon.minOrder) return 0;

  let discount = 0;
  if (coupon.type === 'percentage') {
    discount = (subtotal * coupon.value) / 100;
  } else {
    discount = coupon.value;
  }

  if (coupon.maxDiscount && discount > coupon.maxDiscount) {
    discount = coupon.maxDiscount;
  }

  return Math.min(subtotal, Math.round(discount * 100) / 100);
}

export function calculateOrderSummary(
  items: CartItem[],
  deliveryFee: number = 0,
  coupon?: Coupon | null
): {
  subtotal: number;
  discount: number;
  deliveryFee: number;
  total: number;
  itemCount: number;
} {
  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discount = applyCoupon(subtotal, coupon);
  const safeDelivery = Math.max(0, deliveryFee);
  const total = Math.max(0, subtotal - discount + safeDelivery);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  return {
    subtotal: Math.round(subtotal * 100) / 100,
    discount,
    deliveryFee: safeDelivery,
    total: Math.round(total * 100) / 100,
    itemCount,
  };
}
